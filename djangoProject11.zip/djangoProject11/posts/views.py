from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse

def index(request):
    if request.method == 'GET':
        username = request.GET.get('username')
        password = request.GET.get('password')
        return HttpResponse(f'Username: {username}, Password: {password}')

def posts(request):
    # Получение всех постов
    pass

def popular_posts(request):
    # Получение популярных постов
    pass

def latest_posts(request):
    # Получение последних постов
    pass

def post_detail(request, post_id):
    # Получение конкретного поста
    pass

def about(request):
    return redirect('/about/', permanent=True)

def contacts(request):
    return redirect('/contacts/', permanent=False)

def access(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == 'admin' and password == 'admin':
            return HttpResponse('All is good')
        else:
            return HttpResponse('Access denied')

def json_view(request):
    data = {
        'username': request.GET.get('username'),
        'password': request.GET.get('password'),
    }
    return JsonResponse(data)

def get_view(request):
    response = render(request, 'posts/get.html')
    response.set_cookie('username', 'admin')
    return response

def set_view(request):
    username = request.COOKIES.get('username')
    return HttpResponse(f'Username: {username}')

from django.http import HttpResponseNotFound

def handler404(request, exception):
    return HttpResponseNotFound('Загрузка страницы была завершена ошибкой')