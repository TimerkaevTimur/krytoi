from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('posts/', views.posts, name='posts'),
    path('posts/popular/', views.popular_posts, name='popular_posts'),
    path('posts/latest/', views.latest_posts, name='latest_posts'),
    path('posts/<int:post_id>/', views.post_detail, name='post_detail'),
    path('about/', views.about, name='about'),
    path('contacts/', views.contacts, name='contacts'),
    path('access/', views.access, name='access'),
    path('json/', views.json_view, name='json'),
    path('get/', views.get_view, name='get'),
    path('set/', views.set_view, name='set'),
]

handler404 = 'posts.views.handler404'